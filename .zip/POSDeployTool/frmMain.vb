﻿Imports System
Imports System.Collections.Generic
Imports System.Drawing
Imports System.Linq
Imports System.Threading
Imports System.Threading.Tasks
Imports System.Windows.Forms
Imports POSDeployTool.Models
Imports POSDeployTool.Services

Public Class frmMain

    Private ReadOnly _storeConfigService As StoreConfigService
    Private ReadOnly _pingService As PingService
    Private ReadOnly _winRmService As WinRmService
    Private ReadOnly _storeBindingSource As BindingSource
    Private ReadOnly _settings As AppSettings

    Private _stores As List(Of StoreInfo)
    Private _operationCancellation As CancellationTokenSource
    Private _isOperationRunning As Boolean

    Public Sub New()
        InitializeComponent()

        _storeConfigService = New StoreConfigService()
        _pingService = New PingService()
        _winRmService = New WinRmService()
        _storeBindingSource = New BindingSource()
        _settings = New AppSettings()
        _stores = New List(Of StoreInfo)()

        dgvStores.DataSource = _storeBindingSource
    End Sub

    Private Sub frmMain_Load(
        ByVal sender As Object,
        ByVal e As EventArgs
    ) Handles MyBase.Load

        Try
            AppPaths.CreateFolders()
            AddLog("POSDeployTool started.")
            LoadStoreConfiguration()

        Catch ex As Exception
            HandleConfigurationError(ex)
        End Try
    End Sub

    Private Sub LoadStoreConfiguration()
        SetBusyState(True, "Loading store configuration...")

        Try
            _stores = _storeConfigService.LoadStores()

            For Each store As StoreInfo In _stores
                EnsureConnectionState(store)
            Next

            ApplyStoreFilter()

            AddLog(
                String.Format(
                    "Loaded {0} store(s) from {1}",
                    _stores.Count,
                    AppPaths.StoreConfigFile))

            Me.Text =
                String.Format(
                    "POS Deploy Tool - {0} Store(s)",
                    _stores.Count)

        Finally
            SetBusyState(False, "Ready")
        End Try
    End Sub

    Private Sub ApplyStoreFilter()
        Dim filterText As String = txtFilter.Text.Trim()
        Dim filteredStores As List(Of StoreInfo)

        If String.IsNullOrWhiteSpace(filterText) Then
            filteredStores =
                _stores.
                Where(Function(store) store.Enabled).
                ToList()
        Else
            filteredStores =
                _stores.
                Where(
                    Function(store)
                        Return store.Enabled AndAlso
                               MatchesFilter(store, filterText)
                    End Function).
                ToList()
        End If

        _storeBindingSource.DataSource = filteredStores
        _storeBindingSource.ResetBindings(False)

        InitializeStatusColumns()
        UpdateStoreCounters()
        UpdateActionButtons()
    End Sub

    Private Shared Function MatchesFilter(
        ByVal store As StoreInfo,
        ByVal filterText As String
    ) As Boolean

        Return ContainsIgnoreCase(store.StoreCode, filterText) OrElse
               ContainsIgnoreCase(store.StoreName, filterText) OrElse
               ContainsIgnoreCase(store.ComputerName, filterText) OrElse
               ContainsIgnoreCase(store.IpAddress, filterText)
    End Function

    Private Shared Function ContainsIgnoreCase(
        ByVal value As String,
        ByVal searchValue As String
    ) As Boolean

        If String.IsNullOrEmpty(value) Then
            Return False
        End If

        Return value.IndexOf(
            searchValue,
            StringComparison.OrdinalIgnoreCase) >= 0
    End Function

    Private Sub InitializeStatusColumns()
        For Each row As DataGridViewRow In dgvStores.Rows
            If row.IsNewRow Then
                Continue For
            End If

            Dim store As StoreInfo =
                TryCast(row.DataBoundItem, StoreInfo)

            If store Is Nothing Then
                Continue For
            End If

            EnsureConnectionState(store)
            RefreshStoreRow(store)

            If dgvStores.Columns.Contains("colVersion") Then
                row.Cells("colVersion").Value = "-"
            End If
        Next
    End Sub

    Private Async Sub btnCheckConnection_Click(
        ByVal sender As Object,
        ByVal e As EventArgs
    ) Handles btnCheckConnection.Click

        If _isOperationRunning Then
            Return
        End If

        dgvStores.EndEdit()
        _storeBindingSource.EndEdit()

        Dim selectedStores As List(Of StoreInfo) =
            _stores.
                Where(
                    Function(store)
                        Return store.Enabled AndAlso store.Selected
                    End Function).
                ToList()

        If selectedStores.Count = 0 Then
            MessageBox.Show(
                "กรุณาเลือก Store อย่างน้อย 1 รายการ",
                "Check Connection",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information)

            Return
        End If

        _operationCancellation = New CancellationTokenSource()

        Try
            _isOperationRunning = True
            SetOperationState(True, "Checking connection...")

            AddLog(
                String.Format(
                    "Starting connection check for {0} store(s). Parallel tasks: {1}, Ping timeout: {2} ms, WinRM timeout: {3} ms.",
                    selectedStores.Count,
                    _settings.MaxParallelTasks,
                    _settings.ConnectionTimeoutMilliseconds,
                    _settings.CommandTimeoutMilliseconds))

            ResetSelectedStoreStatus(selectedStores)

            Await CheckSelectedStoresAsync(
                selectedStores,
                _operationCancellation.Token)

            lblStatus.Text = "Check completed"
            AddLog("Connection check completed.")

        Catch ex As OperationCanceledException
            lblStatus.Text = "Cancelled"
            AddLog("Connection check was cancelled by user.")

        Catch ex As Exception
            lblStatus.Text = "Check failed"
            AddLog("Connection check failed: " & ex.ToString())

            MessageBox.Show(
                ex.Message,
                "Connection Check Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error)

        Finally
            _isOperationRunning = False
            SetOperationState(False, lblStatus.Text)

            If _operationCancellation IsNot Nothing Then
                _operationCancellation.Dispose()
                _operationCancellation = Nothing
            End If
        End Try
    End Sub

    Private Async Function CheckSelectedStoresAsync(
        ByVal stores As IList(Of StoreInfo),
        ByVal cancellationToken As CancellationToken
    ) As Task

        Dim maxParallelTasks As Integer =
            Math.Max(1, _settings.MaxParallelTasks)

        Using semaphore As New SemaphoreSlim(
            maxParallelTasks,
            maxParallelTasks)

            Dim tasks As New List(Of Task)()

            For Each store As StoreInfo In stores
                cancellationToken.ThrowIfCancellationRequested()

                tasks.Add(
                    CheckSingleStoreAsync(
                        store,
                        semaphore,
                        cancellationToken))
            Next

            Await Task.WhenAll(tasks)
        End Using
    End Function

    Private Async Function CheckSingleStoreAsync(
        ByVal store As StoreInfo,
        ByVal semaphore As SemaphoreSlim,
        ByVal cancellationToken As CancellationToken
    ) As Task

        Dim semaphoreEntered As Boolean = False

        Try
            Await semaphore.WaitAsync(cancellationToken)
            semaphoreEntered = True

            cancellationToken.ThrowIfCancellationRequested()

            EnsureConnectionState(store)
            store.Connection.Reset()
            store.Connection.OverallStatus = "Checking Ping"
            RefreshStoreRow(store)

            Dim pingResult As PingCheckResult =
                Await _pingService.CheckAsync(
                    store.IpAddress,
                    _settings.ConnectionTimeoutMilliseconds,
                    cancellationToken)

            store.Connection.PingSuccess = pingResult.Success
            store.Connection.PingStatus = MapPingStatus(pingResult)
            store.Connection.PingMilliseconds =
                pingResult.ResponseTimeMilliseconds
            store.Connection.PingMessage = pingResult.Message
            store.Connection.LastChecked = DateTime.Now

            AddLog(
                String.Format(
                    "[{0}/{1}] Ping {2}: {3} - {4}",
                    store.StoreCode,
                    store.ComputerName,
                    store.IpAddress,
                    pingResult.Status,
                    pingResult.Message))

            If Not pingResult.Success Then
                store.Connection.WinRmSuccess = False
                store.Connection.WinRmStatus =
                    ConnectionStatus.Unknown
                store.Connection.OverallStatus =
                    BuildFailedOverallStatus(
                        pingResult.Status,
                        "Ping failed")

                RefreshStoreRow(store)
                Return
            End If

            store.Connection.OverallStatus = "Checking WinRM"
            RefreshStoreRow(store)

            Dim winRmResult As WinRmCheckResult =
                Await _winRmService.CheckAsync(
                    store,
                    _settings.CommandTimeoutMilliseconds,
                    cancellationToken)

            store.Connection.WinRmStatus =
                MapWinRmStatus(winRmResult)
            store.Connection.WinRmSuccess =
                store.Connection.WinRmStatus =
                    ConnectionStatus.Connected
            store.Connection.WinRmMilliseconds =
                winRmResult.DurationMilliseconds
            store.Connection.HostName =
                If(winRmResult.HostName, String.Empty)
            store.Connection.WinRmMessage =
                If(winRmResult.Message, String.Empty)
            store.Connection.LastChecked = DateTime.Now

            If store.Connection.CanDeploy Then
                store.Connection.OverallStatus =
                    "Ready to deploy"
            Else
                store.Connection.OverallStatus =
                    BuildFailedOverallStatus(
                        winRmResult.Status,
                        "WinRM failed")
            End If

            RefreshStoreRow(store)

            AddLog(
                String.Format(
                    "[{0}/{1}] WinRM {2}: {3} - {4} ({5} ms)",
                    store.StoreCode,
                    store.ComputerName,
                    store.IpAddress,
                    winRmResult.Status,
                    winRmResult.Message,
                    winRmResult.DurationMilliseconds))

        Catch ex As OperationCanceledException
            EnsureConnectionState(store)

            store.Connection.PingSuccess = False
            store.Connection.WinRmSuccess = False
            store.Connection.PingStatus =
                ConnectionStatus.Cancelled
            store.Connection.WinRmStatus =
                ConnectionStatus.Cancelled
            store.Connection.OverallStatus =
                "Cancelled"
            store.Connection.LastChecked =
                DateTime.Now

            RefreshStoreRow(store)
            Throw

        Catch ex As Exception
            EnsureConnectionState(store)

            store.Connection.PingSuccess = False
            store.Connection.WinRmSuccess = False

            If store.Connection.PingStatus =
               ConnectionStatus.Unknown Then

                store.Connection.PingStatus =
                    ConnectionStatus.Error
            End If

            store.Connection.WinRmStatus =
                ConnectionStatus.Error
            store.Connection.OverallStatus =
                "Error"
            store.Connection.LastChecked =
                DateTime.Now

            RefreshStoreRow(store)

            AddLog(
                String.Format(
                    "[{0}/{1}] Connection check error: {2}",
                    store.StoreCode,
                    store.ComputerName,
                    ex.Message))

        Finally
            If semaphoreEntered Then
                semaphore.Release()
            End If
        End Try
    End Function

    Private Shared Function MapPingStatus(
        ByVal result As PingCheckResult
    ) As ConnectionStatus

        If result Is Nothing Then
            Return ConnectionStatus.Error
        End If

        If result.Success Then
            Return ConnectionStatus.Online
        End If

        Select Case NormalizeStatus(result.Status)
            Case "timeout"
                Return ConnectionStatus.Timeout

            Case "offline",
                 "unreachable",
                 "failed"
                Return ConnectionStatus.Offline

            Case "cancelled",
                 "canceled"
                Return ConnectionStatus.Cancelled

            Case Else
                Return ConnectionStatus.Error
        End Select
    End Function

    Private Shared Function MapWinRmStatus(
        ByVal result As WinRmCheckResult
    ) As ConnectionStatus

        If result Is Nothing Then
            Return ConnectionStatus.Error
        End If

        If result.Success Then
            Return ConnectionStatus.Connected
        End If

        Select Case NormalizeStatus(result.Status)
            Case "connected"
                Return ConnectionStatus.Connected

            Case "access denied",
                 "accessdenied"
                Return ConnectionStatus.AccessDenied

            Case "unavailable",
                 "offline",
                 "unreachable"
                Return ConnectionStatus.Unavailable

            Case "name mismatch",
                 "namemismatch"
                Return ConnectionStatus.NameMismatch

            Case "timeout"
                Return ConnectionStatus.Timeout

            Case "not configured",
                 "notconfigured"
                Return ConnectionStatus.NotConfigured

            Case "cancelled",
                 "canceled"
                Return ConnectionStatus.Cancelled

            Case Else
                Return ConnectionStatus.Error
        End Select
    End Function

    Private Shared Function NormalizeStatus(
        ByVal value As String
    ) As String

        If String.IsNullOrWhiteSpace(value) Then
            Return String.Empty
        End If

        Return value.Trim().ToLowerInvariant()
    End Function

    Private Shared Function BuildFailedOverallStatus(
        ByVal serviceStatus As String,
        ByVal fallbackStatus As String
    ) As String

        If String.IsNullOrWhiteSpace(serviceStatus) Then
            Return fallbackStatus
        End If

        Return serviceStatus.Trim()
    End Function

    Private Sub RefreshStoreRow(
        ByVal store As StoreInfo
    )

        If store Is Nothing Then
            Return
        End If

        If Me.IsDisposed OrElse Me.Disposing Then
            Return
        End If

        If Me.InvokeRequired Then
            Try
                Me.BeginInvoke(
                    New Action(Of StoreInfo)(
                        AddressOf RefreshStoreRow),
                    store)

            Catch ex As InvalidOperationException
                ' Form is closing.
            Catch ex As ObjectDisposedException
                ' Form has already been disposed.
            End Try

            Return
        End If

        Dim row As DataGridViewRow =
            FindStoreRow(store)

        If row Is Nothing Then
            Return
        End If

        EnsureConnectionState(store)

        If dgvStores.Columns.Contains("colPing") Then
            row.Cells("colPing").Value =
                BuildPingDisplayText(store.Connection)
        End If

        If dgvStores.Columns.Contains("colWinRm") Then
            row.Cells("colWinRm").Value =
                BuildWinRmDisplayText(store.Connection)
        End If

        If dgvStores.Columns.Contains("colStatus") Then
            row.Cells("colStatus").Value =
                BuildOverallStatusText(store.Connection)
        End If

        ApplyConnectionRowStyle(row, store.Connection)

        UpdateStoreCounters()
        UpdateActionButtons()
    End Sub

    Private Shared Function BuildPingDisplayText(
        ByVal connection As ConnectionState
    ) As String

        If connection Is Nothing Then
            Return "-"
        End If

        Select Case connection.PingStatus
            Case ConnectionStatus.Unknown
                Return "-"

            Case ConnectionStatus.Online
                If connection.PingMilliseconds >= 0 Then
                    Return String.Format(
                        "Online ({0} ms)",
                        connection.PingMilliseconds)
                End If

                Return "Online"

            Case ConnectionStatus.Offline
                Return "Offline"

            Case ConnectionStatus.Timeout
                Return "Timeout"

            Case ConnectionStatus.Error
                Return "Error"

            Case ConnectionStatus.Cancelled
                Return "Cancelled"

            Case Else
                Return connection.PingStatus.ToString()
        End Select
    End Function

    Private Shared Function BuildWinRmDisplayText(
        ByVal connection As ConnectionState
    ) As String

        If connection Is Nothing Then
            Return "-"
        End If

        Select Case connection.WinRmStatus
            Case ConnectionStatus.Unknown
                Return "-"

            Case ConnectionStatus.Connected
                If Not String.IsNullOrWhiteSpace(
                    connection.HostName) Then

                    Return String.Format(
                        "Connected ({0})",
                        connection.HostName)
                End If

                Return "Connected"

            Case ConnectionStatus.AccessDenied
                Return "Access denied"

            Case ConnectionStatus.Unavailable
                Return "Unavailable"

            Case ConnectionStatus.Timeout
                Return "Timeout"

            Case ConnectionStatus.NameMismatch
                If Not String.IsNullOrWhiteSpace(
                    connection.HostName) Then

                    Return String.Format(
                        "Name mismatch ({0})",
                        connection.HostName)
                End If

                Return "Name mismatch"

            Case ConnectionStatus.NotConfigured
                Return "Not configured"

            Case ConnectionStatus.Error
                Return "Error"

            Case ConnectionStatus.Cancelled
                Return "Cancelled"

            Case Else
                Return connection.WinRmStatus.ToString()
        End Select
    End Function

    Private Shared Function BuildOverallStatusText(
        ByVal connection As ConnectionState
    ) As String

        If connection Is Nothing Then
            Return "Ready"
        End If

        If Not String.IsNullOrWhiteSpace(
            connection.OverallStatus) Then

            Return connection.OverallStatus
        End If

        If connection.CanDeploy Then
            Return "Ready to deploy"
        End If

        If connection.PingStatus <>
           ConnectionStatus.Online Then

            Return connection.PingStatus.ToString()
        End If

        Return connection.WinRmStatus.ToString()
    End Function

    Private Shared Sub ApplyConnectionRowStyle(
        ByVal row As DataGridViewRow,
        ByVal connection As ConnectionState
    )

        If row Is Nothing OrElse connection Is Nothing Then
            Return
        End If

        row.DefaultCellStyle.BackColor =
            SystemColors.Window
        row.DefaultCellStyle.ForeColor =
            SystemColors.ControlText

        If connection.CanDeploy Then
            row.DefaultCellStyle.BackColor =
                Color.Honeydew
            Return
        End If

        Select Case connection.OverallStatus
            Case "Checking Ping",
                 "Checking WinRM",
                 "Queued"

                row.DefaultCellStyle.BackColor =
                    Color.LightYellow

            Case "Cancelled"
                row.DefaultCellStyle.BackColor =
                    Color.Gainsboro

            Case Else
                If IsConnectionFailure(connection) Then
                    row.DefaultCellStyle.BackColor =
                        Color.MistyRose
                End If
        End Select
    End Sub

    Private Shared Function IsConnectionFailure(
        ByVal connection As ConnectionState
    ) As Boolean

        Return connection.PingStatus =
                   ConnectionStatus.Offline OrElse
               connection.PingStatus =
                   ConnectionStatus.Timeout OrElse
               connection.PingStatus =
                   ConnectionStatus.Error OrElse
               connection.WinRmStatus =
                   ConnectionStatus.AccessDenied OrElse
               connection.WinRmStatus =
                   ConnectionStatus.Unavailable OrElse
               connection.WinRmStatus =
                   ConnectionStatus.NameMismatch OrElse
               connection.WinRmStatus =
                   ConnectionStatus.Timeout OrElse
               connection.WinRmStatus =
                   ConnectionStatus.NotConfigured OrElse
               connection.WinRmStatus =
                   ConnectionStatus.Error
    End Function

    Private Function FindStoreRow(
        ByVal store As StoreInfo
    ) As DataGridViewRow

        For Each row As DataGridViewRow In dgvStores.Rows
            If row.IsNewRow Then
                Continue For
            End If

            Dim rowStore As StoreInfo =
                TryCast(row.DataBoundItem, StoreInfo)

            If rowStore Is store Then
                Return row
            End If

            If rowStore IsNot Nothing AndAlso
               String.Equals(
                   rowStore.StoreCode,
                   store.StoreCode,
                   StringComparison.OrdinalIgnoreCase) Then

                Return row
            End If
        Next

        Return Nothing
    End Function

    Private Shared Sub EnsureConnectionState(
        ByVal store As StoreInfo
    )

        If store IsNot Nothing AndAlso
           store.Connection Is Nothing Then

            store.Connection = New ConnectionState()
        End If
    End Sub

    Private Sub ResetSelectedStoreStatus(
        ByVal selectedStores As IEnumerable(Of StoreInfo)
    )

        If selectedStores Is Nothing Then
            Return
        End If

        For Each store As StoreInfo In selectedStores
            EnsureConnectionState(store)
            store.Connection.Reset()
            store.Connection.OverallStatus = "Queued"
            RefreshStoreRow(store)
        Next
    End Sub

    Private Sub btnStop_Click(
        ByVal sender As Object,
        ByVal e As EventArgs
    ) Handles btnStop.Click

        If _operationCancellation Is Nothing Then
            Return
        End If

        If _operationCancellation.IsCancellationRequested Then
            Return
        End If

        lblStatus.Text = "Cancelling..."
        btnStop.Enabled = False

        AddLog("Cancellation requested by user.")
        _operationCancellation.Cancel()
    End Sub

    Private Sub btnReload_Click(
        ByVal sender As Object,
        ByVal e As EventArgs
    ) Handles btnReload.Click

        If _isOperationRunning Then
            Return
        End If

        Try
            AddLog("Reloading store configuration...")
            LoadStoreConfiguration()

        Catch ex As Exception
            HandleConfigurationError(ex)
        End Try
    End Sub

    Private Sub txtFilter_TextChanged(
        ByVal sender As Object,
        ByVal e As EventArgs
    ) Handles txtFilter.TextChanged

        If _isOperationRunning Then
            Return
        End If

        ApplyStoreFilter()
    End Sub

    Private Sub dgvStores_CurrentCellDirtyStateChanged(
        ByVal sender As Object,
        ByVal e As EventArgs
    ) Handles dgvStores.CurrentCellDirtyStateChanged

        If dgvStores.IsCurrentCellDirty Then
            dgvStores.CommitEdit(
                DataGridViewDataErrorContexts.Commit)
        End If
    End Sub

    Private Sub dgvStores_CellValueChanged(
        ByVal sender As Object,
        ByVal e As DataGridViewCellEventArgs
    ) Handles dgvStores.CellValueChanged

        If e.RowIndex < 0 OrElse e.ColumnIndex < 0 Then
            Return
        End If

        If dgvStores.Columns(e.ColumnIndex).Name =
           "colSelected" Then

            UpdateStoreCounters()
            UpdateActionButtons()
        End If
    End Sub

    Private Sub btnClearLog_Click(
        ByVal sender As Object,
        ByVal e As EventArgs
    ) Handles btnClearLog.Click

        rtbLog.Clear()
        AddLog("On-screen log cleared.")
    End Sub

    Private Sub UpdateStoreCounters()
        Dim visibleStores As List(Of StoreInfo) =
            GetVisibleStores()

        Dim selectedCount As Integer =
    visibleStores.
    Where(Function(store) store.Selected).
    Count()

        Dim connectedCount As Integer =
    visibleStores.
    Where(Function(store)

              EnsureConnectionState(store)

              Return store.Connection.WinRmStatus =
                     ConnectionStatus.Connected

          End Function).
    Count()

        Dim deployableCount As Integer =
    visibleStores.
    Where(Function(store)

              EnsureConnectionState(store)

              Return store.Selected AndAlso
                     store.Connection.CanDeploy

          End Function).
    Count()

        lblSelectedCount.Text =
            String.Format(
                "Selected: {0} | Connected: {1} | Deployable: {2}",
                selectedCount,
                connectedCount,
                deployableCount)

        lblTotalCount.Text =
            String.Format(
                "Total: {0}",
                visibleStores.Count)
    End Sub

    Private Function GetVisibleStores() As List(Of StoreInfo)
        Dim stores As New List(Of StoreInfo)()

        For Each row As DataGridViewRow In dgvStores.Rows
            If row.IsNewRow Then
                Continue For
            End If

            Dim store As StoreInfo =
                TryCast(row.DataBoundItem, StoreInfo)

            If store IsNot Nothing Then
                stores.Add(store)
            End If
        Next

        Return stores
    End Function

    Private Function GetSelectedVisibleStoreCount() As Integer
        Return GetVisibleStores().
    Where(Function(store) store.Selected).
    Count()
    End Function

    Private Function HasDeployableSelectedStores() As Boolean
        Return _stores.Any(
            Function(store)
                If store Is Nothing OrElse
                   Not store.Enabled OrElse
                   Not store.Selected Then

                    Return False
                End If

                EnsureConnectionState(store)
                Return store.Connection.CanDeploy
            End Function)
    End Function

    Private Sub UpdateActionButtons()
        Dim hasSelectedStores As Boolean =
            GetSelectedVisibleStoreCount() > 0

        btnCheckConnection.Enabled =
            Not _isOperationRunning AndAlso
            hasSelectedStores

        btnDeploy.Enabled =
            Not _isOperationRunning AndAlso
            HasDeployableSelectedStores()

        btnStop.Enabled = _isOperationRunning
    End Sub

    Private Sub SetBusyState(
        ByVal isBusy As Boolean,
        ByVal statusText As String
    )

        btnReload.Enabled = Not isBusy
        txtFilter.Enabled = Not isBusy

        lblStatus.Text = statusText
        Me.UseWaitCursor = isBusy

        Application.DoEvents()
    End Sub

    Private Sub SetOperationState(
        ByVal isRunning As Boolean,
        ByVal statusText As String
    )

        btnReload.Enabled = Not isRunning
        btnCheckConnection.Enabled = Not isRunning
        btnDeploy.Enabled = False
        btnStop.Enabled = isRunning

        txtFilter.Enabled = Not isRunning
        dgvStores.Enabled = Not isRunning

        lblStatus.Text = statusText
        Me.UseWaitCursor = False

        If Not isRunning Then
            UpdateActionButtons()
        End If
    End Sub

    Private Sub AddLog(
        ByVal message As String
    )

        If Me.IsDisposed OrElse Me.Disposing Then
            Return
        End If

        If Me.InvokeRequired Then
            Try
                Me.BeginInvoke(
                    New Action(Of String)(
                        AddressOf AddLog),
                    message)

            Catch ex As InvalidOperationException
                ' Form is closing.
            Catch ex As ObjectDisposedException
                ' Form has already been disposed.
            End Try

            Return
        End If

        Dim logLine As String =
            String.Format(
                "{0:yyyy-MM-dd HH:mm:ss}  {1}",
                DateTime.Now,
                message)

        rtbLog.AppendText(
            logLine &
            Environment.NewLine)

        rtbLog.SelectionStart = rtbLog.TextLength
        rtbLog.ScrollToCaret()

        FileLogger.Write(message)
    End Sub

    Private Sub HandleConfigurationError(
        ByVal ex As Exception
    )

        AddLog(
            "Failed to load store configuration: " &
            ex.ToString())

        lblStatus.Text = "Configuration Error"

        MessageBox.Show(
            ex.Message &
            Environment.NewLine &
            Environment.NewLine &
            "Configuration file:" &
            Environment.NewLine &
            AppPaths.StoreConfigFile,
            "Configuration Error",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error)
    End Sub

    Private Sub frmMain_FormClosing(
        ByVal sender As Object,
        ByVal e As FormClosingEventArgs
    ) Handles MyBase.FormClosing

        If Not _isOperationRunning Then
            Return
        End If

        Dim answer As DialogResult =
            MessageBox.Show(
                "มีการตรวจสอบ Connection กำลังทำงานอยู่" &
                Environment.NewLine &
                "ต้องการยกเลิกและปิดโปรแกรมหรือไม่?",
                "POS Deploy Tool",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question)

        If answer = DialogResult.No Then
            e.Cancel = True
            Return
        End If

        If _operationCancellation IsNot Nothing Then
            _operationCancellation.Cancel()
        End If
    End Sub

    Private Sub frmMain_FormClosed(
        ByVal sender As Object,
        ByVal e As FormClosedEventArgs
    ) Handles MyBase.FormClosed

        If _operationCancellation IsNot Nothing Then
            _operationCancellation.Dispose()
            _operationCancellation = Nothing
        End If

        FileLogger.Write("POSDeployTool closed.")
    End Sub

End Class
